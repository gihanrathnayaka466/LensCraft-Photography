<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_set_cookie_params([
        'httponly' => true,
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'samesite' => 'Lax',
        'path' => '/photographsite'
    ]);
    session_start();
}

if (!isset($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

function e(?string $value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
function redirect(string $url): never {
    header('Location: ' . $url);
    exit;
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">';
}
function verify_csrf(): void {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(419);
        exit('Invalid security token. Please go back and try again.');
    }
}
function is_logged_in(): bool { return !empty($_SESSION['user_id']); }
function user_id(): ?int { return isset($_SESSION['user_id']) ? (int)$_SESSION['user_id'] : null; }
function require_login(): void {
    if (!is_logged_in()) redirect('login.php?next=' . urlencode($_SERVER['REQUEST_URI'] ?? 'index.php'));
}
function require_admin(): void {
    require_login();
    $u = current_user();
    if (!$u || ($u['role'] ?? '') !== 'admin') {
        http_response_code(403);
        exit('Access denied. Administrator account required.');
    }
}
function current_user(): ?array {
    static $user = false;
    if ($user !== false) return $user;
    if (!is_logged_in()) return null;
    $stmt = db()->prepare('SELECT id, fullname, email, phone, address, role FROM users WHERE id=? LIMIT 1');
    $stmt->bind_param('i', $_SESSION['user_id']);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc() ?: null;
    return $user;
}
function db(): mysqli { global $conn; return $conn; }
function flash(string $type, string $message): void { $_SESSION['flash'][] = [$type, $message]; }
function flashes(): array {
    $x = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $x;
}
function money(float $n): string { return 'Rs. ' . number_format($n, 2); }
function cart(): array { return $_SESSION['cart'] ?? []; }
function cart_count(): int { return count($_SESSION['cart'] ?? []); }
function cart_total(): float {
    $total=0;
    foreach ($_SESSION['cart'] ?? [] as $item) $total += (float)$item['price'];
    return $total;
}
function payhere_action(): string {
    return PAYHERE_MODE === 'live'
        ? 'https://www.payhere.lk/pay/checkout'
        : 'https://sandbox.payhere.lk/pay/checkout';
}
function payhere_hash(string $merchantId, string $orderId, float $amount, string $currency, string $secret): string {
    $amountFormatted = number_format($amount, 2, '.', '');
    return strtoupper(md5($merchantId . $orderId . $amountFormatted . $currency . strtoupper(md5($secret))));
}
function split_name(string $full): array {
    $parts = preg_split('/\s+/', trim($full), 2);
    return [$parts[0] ?? 'Customer', $parts[1] ?? ''];
}
