<?php
require_once __DIR__.'/bootstrap.php';
require_admin();
$db=db();
$stats=[];
foreach(['users'=>'SELECT COUNT(*) n FROM users','packages'=>'SELECT COUNT(*) n FROM packages WHERE is_active=1','bookings'=>'SELECT COUNT(*) n FROM bookings','low_stock'=>'SELECT COUNT(*) n FROM packages WHERE is_active=1 AND stock_qty<=5'] as $k=>$sql){$stats[$k]=(int)$db->query($sql)->fetch_assoc()['n'];}
$packages=$db->query("SELECT pa.*,p.studio_name FROM packages pa JOIN photographers p ON p.id=pa.photographer_id ORDER BY pa.id DESC")->fetch_all(MYSQLI_ASSOC);
$photographers=$db->query("SELECT id,studio_name FROM photographers WHERE is_active=1 ORDER BY studio_name")->fetch_all(MYSQLI_ASSOC);
$bookings=$db->query("SELECT b.id,b.booking_code,b.booking_date,b.amount,b.status,u.fullname,p.studio_name,pa.name package_name,COALESCE(pm.status,'pending') payment_status FROM bookings b JOIN users u ON u.id=b.user_id JOIN photographers p ON p.id=b.photographer_id JOIN packages pa ON pa.id=b.package_id LEFT JOIN payments pm ON pm.id=(SELECT MAX(id) FROM payments WHERE booking_id=b.id) ORDER BY b.created_at DESC LIMIT 100")->fetch_all(MYSQLI_ASSOC);
$users=$db->query("SELECT id,fullname,email,role,created_at FROM users ORDER BY id DESC LIMIT 100")->fetch_all(MYSQLI_ASSOC);
$page_title='Admin Dashboard | LensCraft'; require __DIR__.'/partials_header.php';
?>
<div class="container lc-admin-page">
 <div class="lc-admin-head"><div><span class="eyebrow">WEEK 08 · DATABASE + ADMIN</span><h1>Admin dashboard</h1><p class="muted">Persistent database management for packages, inventory, bookings and users.</p></div></div>
 <section class="lc-admin-stats">
  <div><span>Users</span><strong><?= $stats['users'] ?></strong></div><div><span>Active packages</span><strong><?= $stats['packages'] ?></strong></div><div><span>Bookings</span><strong><?= $stats['bookings'] ?></strong></div><div><span>Low stock</span><strong><?= $stats['low_stock'] ?></strong></div>
 </section>
 <section class="lc-card"><div class="lc-card-heading"><h2>Product / Package CRUD & Inventory</h2></div>
  <form class="lc-admin-form" method="post" action="admin_action.php"><?= csrf_field() ?><input type="hidden" name="action" value="add_package">
   <select name="photographer_id" required><option value="">Photographer</option><?php foreach($photographers as $ph): ?><option value="<?= (int)$ph['id'] ?>"><?= e($ph['studio_name']) ?></option><?php endforeach; ?></select>
   <input name="name" placeholder="Package name" required maxlength="120"><input type="number" name="price" min="1" step="0.01" placeholder="Price" required><input type="number" name="stock_qty" min="0" value="99" placeholder="Stock" required><input type="number" name="duration_hours" min="0.5" max="48" step="0.5" value="2" required><button class="btn btn-primary">Add package</button>
  </form>
  <div class="table-wrap"><table><thead><tr><th>ID</th><th>Studio / Package</th><th>Price</th><th>Stock</th><th>Status</th><th>Save</th></tr></thead><tbody>
  <?php foreach($packages as $x): ?><tr><form method="post" action="admin_action.php"><?= csrf_field() ?><input type="hidden" name="action" value="edit_package"><input type="hidden" name="id" value="<?= (int)$x['id'] ?>"><td>#<?= (int)$x['id'] ?></td><td><small><?= e($x['studio_name']) ?></small><input name="name" value="<?= e($x['name']) ?>" required></td><td><input type="number" name="price" min="1" step="0.01" value="<?= e((string)$x['price']) ?>" required></td><td><input type="number" name="stock_qty" min="0" value="<?= (int)$x['stock_qty'] ?>" required></td><td><select name="is_active"><option value="1" <?= $x['is_active']?'selected':'' ?>>Active</option><option value="0" <?= !$x['is_active']?'selected':'' ?>>Inactive</option></select></td><td><button class="btn btn-ghost">Save</button></td></form></tr><?php endforeach; ?>
  </tbody></table></div>
 </section>
 <section class="lc-card"><div class="lc-card-heading"><h2>Customer bookings / orders</h2></div><div class="table-wrap"><table><thead><tr><th>Booking</th><th>Customer</th><th>Package</th><th>Total</th><th>Payment</th><th>Booking status</th></tr></thead><tbody>
 <?php foreach($bookings as $b): ?><tr><td><strong><?= e($b['booking_code']) ?></strong><small><?= e($b['booking_date']) ?></small></td><td><?= e($b['fullname']) ?></td><td><?= e($b['studio_name'].' · '.$b['package_name']) ?></td><td><?= money((float)$b['amount']) ?></td><td><span class="status <?= e($b['payment_status']) ?>"><?= e(ucfirst($b['payment_status'])) ?></span></td><td><form method="post" action="admin_action.php" class="lc-inline-form"><?= csrf_field() ?><input type="hidden" name="action" value="booking_status"><input type="hidden" name="id" value="<?= (int)$b['id'] ?>"><select name="status"><?php foreach(['pending','confirmed','completed','cancelled'] as $st): ?><option value="<?= $st ?>" <?= $b['status']===$st?'selected':'' ?>><?= ucfirst($st) ?></option><?php endforeach; ?></select><button class="btn btn-ghost">Update</button></form></td></tr><?php endforeach; ?>
 </tbody></table></div></section>
 <section class="lc-card"><div class="lc-card-heading"><h2>Users & role-based access</h2></div><div class="table-wrap"><table><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Created</th></tr></thead><tbody><?php foreach($users as $u): ?><tr><td>#<?= (int)$u['id'] ?></td><td><?= e($u['fullname']) ?></td><td><?= e($u['email']) ?></td><td><span class="status"><?= e($u['role']) ?></span></td><td><?= e($u['created_at']) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
</div>
<?php require __DIR__.'/partials_footer.php'; ?>
