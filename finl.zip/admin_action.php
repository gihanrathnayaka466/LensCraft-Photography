<?php
require_once __DIR__.'/bootstrap.php';
require_admin();
if($_SERVER['REQUEST_METHOD']!=='POST') redirect('admin.php');
verify_csrf(); $db=db(); $action=(string)($_POST['action']??'');
try{
 if($action==='add_package'){
  $pid=(int)($_POST['photographer_id']??0);$name=trim((string)($_POST['name']??''));$price=(float)($_POST['price']??0);$stock=(int)($_POST['stock_qty']??0);$duration=(float)($_POST['duration_hours']??2);
  if($pid<1||$name===''||$price<=0||$stock<0||$duration<=0)throw new RuntimeException('Enter valid package details.');
  $desc='Admin-created package';$q=$db->prepare('INSERT INTO packages(photographer_id,name,description,price,duration_hours,stock_qty,is_active) VALUES(?,?,?,?,?,?,1)');$q->bind_param('issddi',$pid,$name,$desc,$price,$duration,$stock);$q->execute();flash('success','Package added to database.');
 }elseif($action==='edit_package'){
  $id=(int)($_POST['id']??0);$name=trim((string)($_POST['name']??''));$price=(float)($_POST['price']??0);$stock=(int)($_POST['stock_qty']??0);$active=(int)($_POST['is_active']??0);
  if($id<1||$name===''||$price<=0||$stock<0||!in_array($active,[0,1],true))throw new RuntimeException('Invalid package update.');
  $q=$db->prepare('UPDATE packages SET name=?,price=?,stock_qty=?,is_active=? WHERE id=?');$q->bind_param('sdiii',$name,$price,$stock,$active,$id);$q->execute();flash('success','Package and inventory updated.');
 }elseif($action==='booking_status'){
  $id=(int)($_POST['id']??0);$status=(string)($_POST['status']??'');if($id<1||!in_array($status,['pending','confirmed','completed','cancelled'],true))throw new RuntimeException('Invalid booking status.');
  $q=$db->prepare('UPDATE bookings SET status=? WHERE id=?');$q->bind_param('si',$status,$id);$q->execute();flash('success','Booking status saved.');
 }else throw new RuntimeException('Unknown admin action.');
}catch(Throwable $e){flash('error',$e instanceof RuntimeException?$e->getMessage():'Admin update failed.');}
redirect('admin.php');
